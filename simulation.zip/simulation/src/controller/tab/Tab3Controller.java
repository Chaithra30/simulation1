/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tab;

import controller.MainController;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;



/**
 *
 * @author SB00519010
 */
public class Tab3Controller {
    
    private MainController main;
    
    @FXML
    private ComboBox icmcombo;
    @FXML
    public List<String> scmfulleq=new ArrayList<String>();
    @FXML
    public List<String> scmlefteq=new ArrayList<String>();
    @FXML
    public List<String> scmrighteq=new ArrayList<String>();
    @FXML
    public List<String> icmfulleq=new ArrayList<String>();
    @FXML
    public List<String> icmlefteq=new ArrayList<String>();
    @FXML
    public List<String> icmrighteq=new ArrayList<String>();
    @FXML
    public List<String> frmfulleq=new ArrayList<String>();
    @FXML
    public List<String> frmlefteq=new ArrayList<String>();
    @FXML
    public List<String> frmrighteq=new ArrayList<String>();
    @FXML
     public List<String> dynvaluefulleq=new ArrayList<String>();
   
    @FXML
    private ComboBox scmcombo;
    @FXML
    private ComboBox frmcombo;
    @FXML
    private String fname;
    @FXML 
    public String path;
    @FXML
    public  ArrayList<String> regCon = new ArrayList<String>();
    @FXML
    List<String> paths = new ArrayList<String>();
    @FXML
     List<String>  allscmslectedvalues =new ArrayList<String>(); 
    @FXML
     List<String>  allicmslectedvalues =new ArrayList<String>(); 
     
      public void getFilePath(List<File> file)
   {
      
       System.out.println(file.get(0).getPath());
    
     for(int i=0;i<file.size();i++){
         System.out.println(file.get(i).getPath());
       paths.add(file.get(i).getPath());
   }
       comboSelections();
   }
      
     
    
    private void comboSelections(){
        for(int i =0;i<paths.size();i++){
       String line;
      
                         try
	                    {BufferedReader reader = new BufferedReader(new FileReader(paths.get(i)));
                            File f = new File(paths.get(i));
                            System.out.println(f.getName());
                            //System.out.println(paths.get(0).lastIndexOf("\\")+1);
	                    while ((line = reader.readLine()) != null)
	                    {
                                line= line.replaceAll("	","").replaceAll(" ","").replaceAll(";", "");
                                //System.out.println(line);
	                        String[] parts = line.split("=", 2);
	                        if (parts.length >= 2)
	                        {
	                            String key = parts[0];
	                            String value = parts[1];
                                    
                                    if(f.getName().contains("icm"))
                                    {
                                         icmcombo.getItems().add(key);
                                         icmfulleq.add(line);
                                         icmlefteq.add(key);
                                         icmrighteq.add(value);
                                         icmcombo.setVisible(true);
                                    }
                                    else if(f.getName().contains("init")){
                                            scmcombo.getItems().add(key);
                                            scmfulleq.add(line);
                                            scmlefteq.add(key);
                                            scmrighteq.add(value);
                                            scmcombo.setVisible(true);
                                            }
                                    else if(f.getName().contains("frm")){
                                            fname=paths.get(i);
                                            frmcombo.getItems().add(key);
                                            frmfulleq.add(line);
                                            frmlefteq.add(key);
                                            frmrighteq.add(value);
                                            frmcombo.setVisible(true);
                                            }
                                     //else if(f.getName().contains("dyn")){
                                        //  dynvaluefulleq.add(line);
                                        //  }
                                }
	                            
	                         else {
	                            System.out.println("ignoring line: " + line);
	                        }
	                       
	                    } }
                         
                         
                         catch(IOException s){ 
	                        System.out.println("Error, could not read file"); 

	                    }
                         
        }
    String line2;
                         
                          for(int j =0; j<paths.size(); j++){
                          try
	                    {
                                BufferedReader reader = new BufferedReader(new FileReader(paths.get(j)));
                            
                            File f = new File(paths.get(j));
                         while ((line2 = reader.readLine()) != null)
	                    {
                                //line2= line2.replaceAll("[","").replaceAll("]","");
                                if(f.getName().contains("dyn")){
                                    dynvaluefulleq.clear();
                                          dynvaluefulleq.add(line2);
                                          System.out.println("LINES2::"+dynvaluefulleq );
                                           main.setAllDynValues(dynvaluefulleq);
                                          }
                                else {
	                            //System.out.println("ignoring line2:");
	                        }
                            }
                        
                         }
                           catch(IOException e){ 
	                        System.out.println("Error, could not read file"); 

	                    }
                          }
    
         //System.out.println(path);
        for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("Rk");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
        if (m1.find()) {  
            regCon.add(x);
            System.out.println(x);
                       }      
            }
       // for(String z :dynvaluefulleq){
          //  dynvaluefulleq2.add(z);
          //  System.out.println("LINES2::"+dynvaluefulleq2);
        //}
             
    }
     
       
    @FXML private void onScmComboSelect(ActionEvent event) {
        
        System.out.println(scmcombo.getSelectionModel().getSelectedItem());
        
        String scmselectedvalue=scmcombo.getSelectionModel().getSelectedItem().toString();
      //  if(frmfulleq.size()!=0){
        
            if(frmfulleq.isEmpty())
            {
            System.out.println("please upload file");
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Upload FRM FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();

            
        }
        else
        {
         
            scmselectedvalue=scmselectedvalue.replace("[", "\\[").replace("]", "\\]");
            allscmslectedvalues.clear();
           
           for(String y :regCon){        
          
               Pattern p2 = Pattern.compile(scmselectedvalue+"\\*Rk");
               
               Matcher m2 = p2.matcher(y);
                if (m2.find()) {  
            //regCon.add(x);
             System.out.println(y);
             allscmslectedvalues.add(y);
           
           //System.out.println(x);
                       }                   
                
            }
           if(allscmslectedvalues.isEmpty())
           {
               allscmslectedvalues.add("no values detected");
           }
               
                main.getAllScmSelectedValues(allscmslectedvalues);
               
                 
           }
    
        
    }
        
        
    
    
    @FXML private void onIcmComboSelect(ActionEvent event) {
        
        System.out.println(icmcombo.getSelectionModel().getSelectedItem());
        //allicmslectedvalues.add((String) icmcombo.getSelectionModel().getSelectedItem());

        if(allicmslectedvalues.isEmpty())
           {
               allicmslectedvalues.add("no values detected");
           }
               
                main.getAllIcmSelectedValues(allicmslectedvalues); 
        
        
      /*  Integer one = icmcombo.getSelectionModel().getSelectedIndex();
               String fromvalue= icmrighteq.get(one);
                String fromvalue2= icmlefteq.get(one);
	                    System.out.println(fromvalue);
                            Pattern p = Pattern.compile("-g\\_frm\\[(\\d+)\\]\\)\\*(\\d+)");
        ArrayList<String> numbers = new ArrayList<String>();
   	     Matcher m = p.matcher(fromvalue);
        while (m.find()) {  
            numbers.add(m.group());
            
        }   
        for(String ex :numbers){
           System.out.println("numbers"+ex);
       }
        Pattern p1 = Pattern.compile("g\\_frm\\[(\\d+)\\]");
        ArrayList<String> numbers1 = new ArrayList<String>();
   	     Matcher m1 = p1.matcher(fromvalue);
        while (m1.find()) {  
            numbers1.add(m1.group());
        }   
       // String hi=numbers.size();
       int frm=numbers1.size();
       int frm1=numbers.size();
       int total=frm-frm1;
       
      pvm.setText(String.valueOf(numbers.size()));
      pvm1.setText(String.valueOf(total));
      // }
	TextArea s =new TextArea();
        
     s.prefHeight(20);
     s.maxWidth(20);
     s.maxWidth(20);
s.setPrefColumnCount(5);
s.setPrefRowCount(3);
        
            s.relocate(100, 100);
          Circle c =new Circle();
     
       // c.setRadius(30);
        c.setCenterX(130f);
            c.setCenterY(130f);
           c.setRadius(45.0f);
            c.relocate(525, 230);
            c.setFill(Color.LIGHTCYAN);
            c.setStrokeDashOffset(20);
            c.setStroke(Color.FORESTGREEN);
            Text text = new Text(fromvalue2);
            text.relocate(512, 250);
           for(int i=0;i<=numbers.size();i++){
               
           }
           
           
           
	
       panelLoadLabel.getChildren().add(c);
        panelLoadLabel.getChildren().add(text);
       // panelLoadLabel.getChildren().add(s);
        ArrayList<String> uniquevalues = new ArrayList<String>();
        for (String item :numbers1) {
    if (numbers.contains("-"+item)) {
       
    } else {
       uniquevalues .add(item);
    }
}
       // robot = new Circle(25, Color.BLUE);
  //  robot.relocate(getRandomCoordinates(600), getRandomCoordinates(400));

    ArrayList<TextField> particles = new ArrayList<TextField>();
 int x,y;
 
   List<Line> lo= new ArrayList<Line>(); 
   List<Line> lo2= new ArrayList<Line>(); 
    List<Line> lo3= new ArrayList<Line>();
        //  robot.relocate(getRandomCoordinates(600), getRandomCoordinates(400));

       
  int usize=uniquevalues.size();
      
       if(usize==1 ){
           for(int i =0; i<usize; i++)
   {
        hi = new TextArea();
     x =200+i*200;
        y = 52;
        int o=i-1;
     int    l1=x+50;
       int  l2=y+38;
    line = new Line(l1, l2,  560,   230);
     hi.relocate(x, y);
     hi.setEditable(false);
        hi.setText(uniquevalues.get(i));
        hi.setPrefColumnCount(6);
hi.setPrefRowCount(1);
         fields.add(hi);
lo.add(line);
  
   }          panelLoadLabel.getChildren().addAll(lo);
panelLoadLabel.getChildren().addAll(fields);
       }
       
       
       
        if(usize==2 ){
           for(int i =0; i<usize; i++)
   {
        hi = new TextArea();
      x =200+i*200;
        y = 52;
        int o=i-1;
     int    l1=x+50;
       int  l2=y+38;
    line = new Line(l1, l2,  560,   230);
     hi.relocate(x, y);
     hi.setEditable(false);
        hi.setText(uniquevalues.get(i));
        hi.setPrefColumnCount(6);
hi.setPrefRowCount(1);
         fields.add(hi);
lo.add(line);
  
   }          panelLoadLabel.getChildren().addAll(lo);
panelLoadLabel.getChildren().addAll(fields);
       }

         if(usize>=3 && usize<=5 ){
           for(int i =0; i<usize; i++)
   {
        hi = new TextArea();
       x =100+i*150;
        y = 52;
     int o=i-1;
   
        int    l1=x+50;
         int  l2=y+36;
    line = new Line(l1, l2,  560,   230);
     hi.relocate(x, y);
     hi.setEditable(false);
        hi.setText(uniquevalues.get(i));
        hi.setPrefColumnCount(6);
hi.setPrefRowCount(1);
         fields.add(hi);
lo.add(line);
  
   }          panelLoadLabel.getChildren().addAll(lo);
panelLoadLabel.getChildren().addAll(fields);
       }

          if(usize>5 ){
           for(int i =0; i<usize; i++)
   {
        hi = new TextArea();
       x = 2+i*100;
        y = 52;
     int o=i-1;
    
      int    l1=x+50;
      int  l2=y+36;
    line = new Line(l1, l2,  560,   230);
     hi.relocate(x, y);
     hi.setEditable(false);
        hi.setText(uniquevalues.get(i));
        hi.setPrefColumnCount(6);
hi.setPrefRowCount(1);
         fields.add(hi);
lo.add(line);
  
   }          panelLoadLabel.getChildren().addAll(lo);
panelLoadLabel.getChildren().addAll(fields);
       }
          
          for(int i=0;i<fields.size();i++)
          {
              ConValues.add(fields.get(i).getText());
          }
          for(int i=0;i<fields.size();i++)
          {
              System.out.println(ConValues.get(i));
          }
          
          if(frm1>=1 ){
           for(int i =0; i<frm1; i++)
   {
        hi2 = new TextArea();
     
     x = 2+i*490;
        y = 392;
      int    l1=x+50;
      int  l2=y+36;
    line = new Line(l1, l2,  560,   230);
     hi2.relocate(x, y);
     hi2.setEditable(false);
        hi2.setText(numbers.get(i));
        hi2.setPrefColumnCount(6);
hi2.setPrefRowCount(1);
         fields2.add(hi2);
lo2.add(line);
  
   }          panelLoadLabel.getChildren().addAll(lo2);
panelLoadLabel.getChildren().addAll(fields2);
       
          }
       
waste.setOnAction(new EventHandler<ActionEvent>() {
    public void handle(ActionEvent event) {
       panelLoadLabel.getChildren().clear();
      
       fields.removeAll(fields);
       ConValues.removeAll(ConValues);
       EditValues.removeAll(EditValues);
       
    }
}); */
        
    }
    
     @FXML private void onFrmComboSelect(ActionEvent event) {
        
    }
    
    
    public void init(MainController mainController) {
		main = mainController;
                
	}

    
    
    
}
